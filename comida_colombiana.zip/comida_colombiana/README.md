# Dataset: comida colombiana 🇨🇴

Imágenes para entrenar un clasificador de comida colombiana (formato ImageFolder: una carpeta por clase).

| Clase | Imágenes |
|---|---|
| ajiaco | 43 |
| arepa | 56 |
| bandeja_paisa | 21 |

- Tamaño: miniaturas de 512 px de ancho (de Wikimedia Commons).
- Las fotos vienen tal cual: no están divididas en train/test. Esa parte va en tu código.
- El dataset está desbalanceado (pocas fotos de bandeja paisa). Considera agregar fotos propias.

## Licencias

Todas las imágenes vienen de **Wikimedia Commons** con licencias libres (CC0, CC BY o CC BY-SA).
Autor, licencia y enlace de cada foto están en `CREDITOS.csv`. Si publicas el dataset, conserva ese archivo:
las licencias CC BY y CC BY-SA exigen dar crédito al autor.
