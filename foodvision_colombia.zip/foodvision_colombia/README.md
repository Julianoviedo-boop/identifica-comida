# 🇨🇴 FoodVision Colombia

Clasificador de comida colombiana con **PyTorch**. Recibe una foto y predice si es **ajiaco**, **arepa** o **bandeja paisa**.

Proyecto de portafolio basado en el curso *Learn PyTorch for Deep Learning* (capítulos 0 al 4), ampliado con **transfer learning**.

---

## 📁 Estructura del proyecto

```
foodvision_colombia/
├── data/
│   ├── raw/                  ← 1. Pon aquí TODAS tus fotos, una carpeta por plato
│   │   ├── ajiaco/
│   │   ├── arepa/
│   │   └── bandeja_paisa/
│   ├── train/                ← 2. Se llena solo con scripts/split_dataset.py (80 %)
│   └── test/                 ←    (20 %)
├── src/                      ← Código reutilizable (como en el curso)
│   ├── config.py             ← Hiperparámetros y rutas en un solo lugar
│   ├── data_setup.py         ← Transforms + ImageFolder + DataLoaders
│   ├── model_builder.py      ← TinyVGG y modelo con transfer learning
│   ├── engine.py             ← train_step, test_step y train
│   └── utils.py              ← Guardar modelo y graficar curvas
├── scripts/
│   └── split_dataset.py      ← Divide data/raw en train/test
├── notebooks/                ← Tus notebooks de exploración (Colab)
├── models/                   ← Modelos entrenados (.pth)
├── results/                  ← Curvas de pérdida y resultados
├── train.py                  ← Entrenar desde la terminal
├── predict.py                ← Predecir una foto nueva
└── requirements.txt
```

---

## 🚀 Cómo usarlo

### 1. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 2. Conseguir las fotos

Reúne fotos de cada plato (mínimo **75 por clase**; ideal **150 o más**) y guárdalas en `data/raw/<plato>/`.

Ideas para conseguirlas:
- Tus propias fotos y las de amigos y familia 📸
- Fotos de restaurantes (pide permiso si las vas a publicar)
- Búsquedas de imágenes con licencia libre (Unsplash, Pexels, Wikimedia Commons)

> Revisa a mano que cada foto esté en la carpeta correcta. **Un dataset limpio vale más que un modelo grande.**

### 3. Dividir en train y test

```bash
python scripts/split_dataset.py
```

### 4. Entrenar

```bash
# Modelo base (TinyVGG, como en el curso)
python train.py --modelo tinyvgg --epochs 10

# Transfer learning (EfficientNet-B0 preentrenado) ← recomendado
python train.py --modelo efficientnet --epochs 5
```

### 5. Predecir una foto nueva

```bash
python predict.py --imagen mi_ajiaco.jpg --modelo efficientnet
```

---

## 💡 Usarlo en Google Colab

Si tu computador no tiene GPU, sube la carpeta del proyecto a Google Drive y en Colab:

```python
from google.colab import drive
drive.mount("/content/drive")
%cd /content/drive/MyDrive/foodvision_colombia
!pip install -q torchinfo
!python train.py --modelo efficientnet --epochs 5
```

Activa la GPU en **Entorno de ejecución → Cambiar tipo de entorno → T4 GPU**.

---

## 📊 Resultados

| Modelo | Épocas | Test acc | Notas |
|---|---|---|---|
| TinyVGG | | | |
| EfficientNet-B0 | | | |

*(Llena esta tabla con tus resultados: es lo primero que mira un reclutador.)*

---

## 🗺️ Próximos pasos

- [ ] Agregar más platos (lechona, sancocho, empanadas, tamal...)
- [ ] Matriz de confusión para ver qué platos se confunden
- [ ] Demo web con **Gradio** en Hugging Face Spaces
- [ ] Publicar el proyecto en GitHub con capturas de las predicciones

---

Hecho por **Julian** · Bogotá, Colombia 🇨🇴
