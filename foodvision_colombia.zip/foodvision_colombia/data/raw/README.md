# 📸 Pon tus fotos aquí

Una carpeta por plato. El nombre de la carpeta es la etiqueta:

```
raw/
├── ajiaco/          foto1.jpg, foto2.jpg, ...
├── arepa/
└── bandeja_paisa/
```

¿Quieres agregar más platos? Crea una carpeta nueva (por ejemplo `lechona/`) y agrega su nombre a `CLASS_NAMES` en `src/config.py`.

Luego ejecuta: `python scripts/split_dataset.py`
