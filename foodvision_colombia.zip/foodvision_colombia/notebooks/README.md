# Notebooks

Aquí van tus notebooks de exploración en Colab. Sugerencias de nombres:

- `01_explorar_datos.ipynb`: contar fotos por plato y ver una cuadrícula al azar
- `02_modelo_base_tinyvgg.ipynb`: el modelo base, con curvas de pérdida
- `03_transfer_learning.ipynb`: EfficientNet-B0 y matriz de confusión

Puedes importar el código del proyecto así:

```python
import sys
sys.path.append("..")
from src.data_setup import create_dataloaders, get_transforms
from src.model_builder import build_model
```
