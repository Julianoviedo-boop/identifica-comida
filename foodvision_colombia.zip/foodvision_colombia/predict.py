"""Predice el plato de una foto nueva (tema 157).

Uso:
    python predict.py --imagen mi_ajiaco.jpg --modelo efficientnet
"""
import argparse
import json

import torch
from PIL import Image

from src import config
from src.data_setup import get_transforms
from src.model_builder import build_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--imagen", required=True, help="Ruta de la foto")
    parser.add_argument("--modelo", choices=["tinyvgg", "efficientnet"], default="efficientnet")
    args = parser.parse_args()

    # Clases guardadas al entrenar (si no existen, se usan las de config)
    clases_path = config.MODELS_DIR / "class_names.json"
    if clases_path.exists():
        class_names = json.loads(clases_path.read_text(encoding="utf-8"))
    else:
        class_names = config.CLASS_NAMES

    # Cargar modelo: crear uno nuevo y ponerle lo aprendido (load_state_dict)
    model = build_model(args.modelo, num_classes=len(class_names))
    pesos = config.MODELS_DIR / f"foodvision_{args.modelo}.pth"
    model.load_state_dict(torch.load(pesos, map_location=config.DEVICE))
    model.to(config.DEVICE).eval()

    # Los 3 grandes: tipo (ToTensor → float 0-1), forma (resize + unsqueeze), device
    pretrained = args.modelo == "efficientnet"
    img_size = config.IMG_SIZE_PRETRAINED if pretrained else config.IMG_SIZE_TINYVGG
    _, test_tf = get_transforms(img_size, pretrained=pretrained)

    img = Image.open(args.imagen).convert("RGB")
    x = test_tf(img).unsqueeze(dim=0).to(config.DEVICE)   # [1, 3, H, W]

    with torch.inference_mode():
        probs = torch.softmax(model(x), dim=1).squeeze().cpu()

    print(f"\n📸 {args.imagen}")
    for nombre, p in sorted(zip(class_names, probs.tolist()), key=lambda t: -t[1]):
        print(f"   {nombre:<15} {p:6.1%}  {'█' * int(p * 30)}")
    print(f"\n🍽️  Predicción: {class_names[probs.argmax()]}")


if __name__ == "__main__":
    main()
