"""Divide las fotos de data/raw/<plato>/ en data/train y data/test.

Uso:
    python scripts/split_dataset.py            # 80 % train, 20 % test
    python scripts/split_dataset.py --test 0.25

Copia los archivos (no los mueve), así data/raw siempre queda intacto.
"""
import argparse
import random
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"
TRAIN_DIR = ROOT / "data" / "train"
TEST_DIR = ROOT / "data" / "test"
EXTENSIONES = {".jpg", ".jpeg", ".png", ".webp"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", type=float, default=0.2, help="Proporción para test")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    clases = sorted(d for d in RAW_DIR.iterdir() if d.is_dir())
    if not clases:
        print(f"❌ No hay carpetas de platos en {RAW_DIR}")
        return

    for clase in clases:
        fotos = sorted(f for f in clase.iterdir() if f.suffix.lower() in EXTENSIONES)
        if not fotos:
            print(f"⚠️  {clase.name}: sin fotos, se omite")
            continue

        random.shuffle(fotos)
        n_test = max(1, int(len(fotos) * args.test))
        divisiones = {TEST_DIR: fotos[:n_test], TRAIN_DIR: fotos[n_test:]}

        for destino, archivos in divisiones.items():
            carpeta = destino / clase.name
            if carpeta.exists():
                shutil.rmtree(carpeta)  # empezar limpio en cada ejecución
            carpeta.mkdir(parents=True)
            for f in archivos:
                shutil.copy2(f, carpeta / f.name)

        print(f"✅ {clase.name}: {len(fotos) - n_test} train | {n_test} test")


if __name__ == "__main__":
    main()
