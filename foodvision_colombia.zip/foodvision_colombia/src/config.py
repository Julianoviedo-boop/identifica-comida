"""Configuración del proyecto: rutas e hiperparámetros en un solo lugar."""
from pathlib import Path

import torch

# --- Rutas ---
ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
TRAIN_DIR = DATA_DIR / "train"
TEST_DIR = DATA_DIR / "test"
MODELS_DIR = ROOT_DIR / "models"
RESULTS_DIR = ROOT_DIR / "results"

# --- Clases (deben coincidir con los nombres de las carpetas) ---
CLASS_NAMES = ["ajiaco", "arepa", "bandeja_paisa"]  # orden alfabético, como ImageFolder

# --- Hiperparámetros ---
SEED = 42
BATCH_SIZE = 32
LEARNING_RATE = 0.001
TEST_SPLIT = 0.2
IMG_SIZE_TINYVGG = 64     # TinyVGG trabaja con imágenes de 64 × 64
IMG_SIZE_PRETRAINED = 224  # EfficientNet espera 224 × 224

# --- Dispositivo (código agnóstico, tema 31) ---
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
