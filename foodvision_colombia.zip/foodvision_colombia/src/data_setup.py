"""Transforms, datasets y DataLoaders (bloques 16 y 17 del curso)."""
import os

from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# Media y desviación de ImageNet: los modelos preentrenados las esperan
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def get_transforms(img_size: int, pretrained: bool = False):
    """Devuelve (train_transform, test_transform).

    La aumentación de datos va SOLO en train (tema 143).
    """
    train_steps = [
        transforms.Resize((img_size, img_size)),
        transforms.TrivialAugmentWide(num_magnitude_bins=31),
        transforms.ToTensor(),
    ]
    test_steps = [
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
    ]
    if pretrained:
        train_steps.append(transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD))
        test_steps.append(transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD))

    return transforms.Compose(train_steps), transforms.Compose(test_steps)


def create_dataloaders(train_dir, test_dir, train_transform, test_transform,
                       batch_size: int, num_workers: int = None):
    """Crea los DataLoaders con ImageFolder (carpeta = etiqueta).

    Devuelve: (train_dataloader, test_dataloader, class_names)
    """
    if num_workers is None:
        num_workers = min(4, os.cpu_count() or 1)

    train_data = datasets.ImageFolder(train_dir, transform=train_transform)
    test_data = datasets.ImageFolder(test_dir, transform=test_transform)

    train_dataloader = DataLoader(train_data, batch_size=batch_size,
                                  shuffle=True, num_workers=num_workers)
    test_dataloader = DataLoader(test_data, batch_size=batch_size,
                                 shuffle=False, num_workers=num_workers)

    return train_dataloader, test_dataloader, train_data.classes
