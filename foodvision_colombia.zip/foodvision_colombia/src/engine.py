"""Bucles de entrenamiento y prueba (bloques 8, 14 y 18 del curso).

🔮 forward → 📏 loss → 🧹 zero_grad → 🔙 backward → 👣 step
"""
import torch
from tqdm.auto import tqdm


def train_step(model, dataloader, loss_fn, optimizer, device):
    model.train()
    train_loss, train_acc = 0.0, 0.0

    for X, y in dataloader:
        X, y = X.to(device), y.to(device)

        y_logits = model(X)                       # 🔮
        loss = loss_fn(y_logits, y)               # 📏
        train_loss += loss.item()

        optimizer.zero_grad()                     # 🧹
        loss.backward()                           # 🔙
        optimizer.step()                          # 👣

        y_pred = y_logits.argmax(dim=1)
        train_acc += (y_pred == y).sum().item() / len(y)

    return train_loss / len(dataloader), train_acc / len(dataloader)


def test_step(model, dataloader, loss_fn, device):
    model.eval()
    test_loss, test_acc = 0.0, 0.0

    with torch.inference_mode():
        for X, y in dataloader:
            X, y = X.to(device), y.to(device)
            y_logits = model(X)
            test_loss += loss_fn(y_logits, y).item()
            y_pred = y_logits.argmax(dim=1)
            test_acc += (y_pred == y).sum().item() / len(y)

    return test_loss / len(dataloader), test_acc / len(dataloader)


def train(model, train_dataloader, test_dataloader, optimizer, loss_fn,
          epochs: int, device) -> dict:
    """Entrena y devuelve el historial por época.

    El optimizador se recibe ya creado A PARTIR DE ESTE MODELO
    (¡nada de optimizadores cruzados! 😉).
    """
    results = {"train_loss": [], "train_acc": [], "test_loss": [], "test_acc": []}
    model.to(device)

    for epoch in tqdm(range(epochs)):
        train_loss, train_acc = train_step(model, train_dataloader, loss_fn, optimizer, device)
        test_loss, test_acc = test_step(model, test_dataloader, loss_fn, device)

        print(f"Época {epoch + 1} | "
              f"train_loss: {train_loss:.4f} | train_acc: {train_acc:.2%} | "
              f"test_loss: {test_loss:.4f} | test_acc: {test_acc:.2%}")

        results["train_loss"].append(train_loss)
        results["train_acc"].append(train_acc)
        results["test_loss"].append(test_loss)
        results["test_acc"].append(test_acc)

    return results
