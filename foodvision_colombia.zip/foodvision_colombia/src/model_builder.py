"""Modelos: TinyVGG (el del curso) y EfficientNet-B0 con transfer learning."""
import torch
from torch import nn
import torchvision


class TinyVGG(nn.Module):
    """La CNN del capítulo 4. Espera imágenes de [N, 3, 64, 64].

    64 → conv 62 → conv 60 → pool 30 → conv 28 → conv 26 → pool 13
    Por eso el Linear recibe hidden_units * 13 * 13.
    """

    def __init__(self, input_shape: int, hidden_units: int, output_shape: int):
        super().__init__()
        self.conv_block_1 = nn.Sequential(
            nn.Conv2d(input_shape, hidden_units, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2),
        )
        self.conv_block_2 = nn.Sequential(
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(hidden_units * 13 * 13, output_shape),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.conv_block_2(self.conv_block_1(x)))


def create_efficientnet_b0(num_classes: int, seed: int = 42) -> nn.Module:
    """Transfer learning: un modelo que YA sabe ver (ImageNet).

    1. Carga los pesos preentrenados.
    2. Congela las capas que detectan bordes, texturas y formas.
    3. Cambia la última capa por una de `num_classes` salidas.
    """
    weights = torchvision.models.EfficientNet_B0_Weights.DEFAULT
    model = torchvision.models.efficientnet_b0(weights=weights)

    for param in model.features.parameters():
        param.requires_grad = False  # congelar: estas capas no se entrenan

    torch.manual_seed(seed)
    model.classifier = nn.Sequential(
        nn.Dropout(p=0.2, inplace=True),
        nn.Linear(in_features=1280, out_features=num_classes),
    )
    return model


def build_model(name: str, num_classes: int, seed: int = 42) -> nn.Module:
    """Crea el modelo pedido: 'tinyvgg' o 'efficientnet'."""
    if name == "tinyvgg":
        torch.manual_seed(seed)
        return TinyVGG(input_shape=3, hidden_units=10, output_shape=num_classes)
    if name == "efficientnet":
        return create_efficientnet_b0(num_classes, seed)
    raise ValueError(f"Modelo desconocido: {name}. Usa 'tinyvgg' o 'efficientnet'.")
