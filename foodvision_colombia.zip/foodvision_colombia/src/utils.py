"""Utilidades: guardar/cargar modelos y graficar curvas."""
from pathlib import Path

import matplotlib.pyplot as plt
import torch


def save_model(model, target_dir, model_name: str):
    """Guarda solo el state_dict (tema 51)."""
    target_dir = Path(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    if not model_name.endswith((".pth", ".pt")):
        model_name += ".pth"
    save_path = target_dir / model_name
    torch.save(obj=model.state_dict(), f=save_path)
    print(f"✅ Modelo guardado en: {save_path}")
    return save_path


def plot_loss_curves(results: dict, save_path=None):
    """Curvas de pérdida y exactitud (tema 151). Sirven para detectar
    underfitting (ambas altas) u overfitting (test sube mientras train baja)."""
    epochs = range(1, len(results["train_loss"]) + 1)
    plt.figure(figsize=(14, 5))

    plt.subplot(1, 2, 1)
    plt.plot(epochs, results["train_loss"], label="train")
    plt.plot(epochs, results["test_loss"], label="test")
    plt.title("Pérdida")
    plt.xlabel("Época")
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(epochs, [a * 100 for a in results["train_acc"]], label="train")
    plt.plot(epochs, [a * 100 for a in results["test_acc"]], label="test")
    plt.title("Exactitud (%)")
    plt.xlabel("Época")
    plt.legend()

    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, bbox_inches="tight")
        print(f"📈 Curvas guardadas en: {save_path}")
    plt.close()
