"""Entrena FoodVision Colombia.

Uso:
    python train.py --modelo tinyvgg --epochs 10
    python train.py --modelo efficientnet --epochs 5
"""
import argparse
import json

import torch
from torch import nn

from src import config
from src.data_setup import create_dataloaders, get_transforms
from src.engine import train
from src.model_builder import build_model
from src.utils import plot_loss_curves, save_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--modelo", choices=["tinyvgg", "efficientnet"], default="efficientnet")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--lr", type=float, default=config.LEARNING_RATE)
    parser.add_argument("--batch", type=int, default=config.BATCH_SIZE)
    args = parser.parse_args()

    pretrained = args.modelo == "efficientnet"
    img_size = config.IMG_SIZE_PRETRAINED if pretrained else config.IMG_SIZE_TINYVGG
    print(f"🖥️  Dispositivo: {config.DEVICE} | Modelo: {args.modelo} | Imagen: {img_size}×{img_size}")

    # 1. 📦 Datos
    train_tf, test_tf = get_transforms(img_size, pretrained=pretrained)
    train_dl, test_dl, class_names = create_dataloaders(
        config.TRAIN_DIR, config.TEST_DIR, train_tf, test_tf, args.batch)
    print(f"🍽️  Clases: {class_names}")

    # 2. 🏗️ Modelo (el optimizador se crea DESPUÉS y desde ESTE modelo)
    model = build_model(args.modelo, num_classes=len(class_names), seed=config.SEED)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        params=[p for p in model.parameters() if p.requires_grad], lr=args.lr)

    # 3-4. 🏋️ Entrenar y 📊 evaluar
    torch.manual_seed(config.SEED)
    results = train(model, train_dl, test_dl, optimizer, loss_fn,
                    epochs=args.epochs, device=config.DEVICE)

    # 6. 💾 Guardar modelo, clases, curvas e historial
    save_model(model, config.MODELS_DIR, f"foodvision_{args.modelo}.pth")
    config.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    with open(config.MODELS_DIR / "class_names.json", "w", encoding="utf-8") as f:
        json.dump(class_names, f, ensure_ascii=False)
    with open(config.RESULTS_DIR / f"historial_{args.modelo}.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    plot_loss_curves(results, config.RESULTS_DIR / f"curvas_{args.modelo}.png")


if __name__ == "__main__":
    main()
